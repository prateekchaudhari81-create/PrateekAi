package com.prateek.ai

import com.prateek.ai.ai.OpenAiJson
import com.prateek.ai.model.ChatMessage
import com.prateek.ai.model.Role
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class OpenAiJsonTest {

    @Test fun requestHasModelSystemPromptAndHistory() {
        val body = OpenAiJson.buildRequest(
            "test-model",
            "be brief",
            listOf(
                ChatMessage(1, Role.USER, "hi"),
                ChatMessage(2, Role.ASSISTANT, "hello")
            )
        )
        val json = JSONObject(body)
        assertEquals("test-model", json.getString("model"))
        val messages = json.getJSONArray("messages")
        assertEquals(3, messages.length())
        assertEquals("system", messages.getJSONObject(0).getString("role"))
        assertEquals("user", messages.getJSONObject(1).getString("role"))
        assertEquals("assistant", messages.getJSONObject(2).getString("role"))
    }

    @Test fun parsesNormalReply() {
        val body = """{"choices":[{"message":{"role":"assistant","content":"  Namaste  "}}]}"""
        assertEquals("Namaste", OpenAiJson.parseReply(body))
    }

    @Test fun badOrEmptyReplyGivesNull() {
        assertNull(OpenAiJson.parseReply("not json"))
        assertNull(OpenAiJson.parseReply("""{"choices":[]}"""))
        assertNull(OpenAiJson.parseReply("""{"choices":[{"message":{"content":""}}]}"""))
    }
}
