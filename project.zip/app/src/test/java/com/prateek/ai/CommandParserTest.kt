package com.prateek.ai

import com.prateek.ai.command.ClarifyKind
import com.prateek.ai.command.Command
import com.prateek.ai.command.CommandParser
import com.prateek.ai.command.KnownApp
import com.prateek.ai.command.SystemSettingsKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CommandParserTest {

    @Test fun opensYoutubeInEnglish() =
        assertEquals(Command.OpenApp(KnownApp.YOUTUBE), CommandParser.parse("open youtube"))

    @Test fun opensYoutubeInHinglish() =
        assertEquals(Command.OpenApp(KnownApp.YOUTUBE), CommandParser.parse("youtube kholo"))

    @Test fun opensYoutubeInHindi() =
        assertEquals(Command.OpenApp(KnownApp.YOUTUBE), CommandParser.parse("यूट्यूब खोलो"))

    @Test fun opensWifiSettings() =
        assertEquals(
            Command.OpenSystemSettings(SystemSettingsKind.WIFI),
            CommandParser.parse("open wifi settings")
        )

    @Test fun opensSettings() =
        assertEquals(
            Command.OpenSystemSettings(SystemSettingsKind.GENERAL),
            CommandParser.parse("open settings")
        )

    @Test fun tellsTime() {
        assertEquals(Command.TellTime, CommandParser.parse("what time is it"))
        assertEquals(Command.TellTime, CommandParser.parse("kitne baje hain"))
    }

    @Test fun tellsDate() =
        assertEquals(Command.TellDate, CommandParser.parse("today's date"))

    @Test fun parsesTimers() {
        assertEquals(Command.SetTimer(300), CommandParser.parse("5 minute ka timer"))
        assertEquals(Command.SetTimer(7200), CommandParser.parse("set a timer for 2 hours"))
        assertEquals(Command.SetTimer(300), CommandParser.parse("5 मिनट का टाइमर"))
    }

    @Test fun timerWithoutDurationAsksQuestion() =
        assertEquals(Command.Clarify(ClarifyKind.TIMER_DURATION), CommandParser.parse("set a timer"))

    @Test fun parsesAlarms() {
        assertEquals(Command.SetAlarm(19, 30), CommandParser.parse("alarm 7:30 pm"))
        assertEquals(Command.SetAlarm(6, 0), CommandParser.parse("alarm 6 baje subah"))
        assertEquals(Command.SetAlarm(0, 15), CommandParser.parse("set alarm 12:15 am"))
    }

    @Test fun alarmWithoutTimeAsksQuestion() =
        assertEquals(Command.Clarify(ClarifyKind.ALARM_TIME), CommandParser.parse("set an alarm"))

    @Test fun invalidAlarmTimeIsRejected() =
        assertEquals(Command.Clarify(ClarifyKind.INVALID_ALARM_TIME), CommandParser.parse("alarm 25:00"))

    @Test fun normalQuestionsGoToTheAi() {
        assertNull(CommandParser.parse("tell me about the history of youtube"))
        assertNull(CommandParser.parse("what time does the match start in mumbai"))
        assertNull(CommandParser.parse("explain how photosynthesis works"))
    }
}
