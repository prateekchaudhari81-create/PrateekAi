package com.prateek.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Wraps Android SpeechRecognizer. Call every method from the main thread. */
class VoiceInput(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onListening()
        fun onLevel(level: Float)
        fun onPartial(text: String)
        fun onResult(text: String)
        fun onError(message: String)
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null

    fun start(languageTag: String, preferOffline: Boolean) {
        destroy()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            listener.onError(
                "Speech recognition is not available on this phone. " +
                    "Enable the Google app, or type instead."
            )
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                if (recognizer === r) listener.onListening()
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                if (recognizer === r) listener.onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                if (recognizer !== r) return
                listener.onError(describeError(error))
                release(r)
            }

            override fun onResults(results: Bundle?) {
                if (recognizer !== r) return
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isBlank()) {
                    listener.onError(describeError(7))
                } else {
                    listener.onResult(text)
                }
                release(r)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                if (recognizer !== r) return
                val text = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isNotBlank()) listener.onPartial(text)
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        r.startListening(intent)
    }

    /** Ask the recognizer to finish and deliver what it heard so far. */
    fun stopListening() {
        recognizer?.stopListening()
    }

    fun destroy() {
        val r = recognizer
        recognizer = null
        if (r != null) {
            r.cancel()
            r.destroy()
        }
    }

    private fun release(r: SpeechRecognizer) {
        main.post {
            r.cancel()
            r.destroy()
            if (recognizer === r) recognizer = null
        }
    }

    private fun describeError(code: Int): String = when (code) {
        1, 2 -> "Network problem. Check your internet and try again."
        3 -> "Microphone audio problem. Try again."
        4 -> "The speech service had a problem. Try again."
        5 -> "Voice input stopped unexpectedly. Try again."
        6 -> "I didn't hear anything. Tap the mic and speak."
        7 -> "I couldn't understand that. Tap the mic and try again."
        8 -> "The speech service is busy. Wait a moment and try again."
        9 -> "Microphone permission is missing. Allow it from the Privacy screen."
        10, 11 -> "The speech service is unavailable right now. Try again soon."
        12, 13 -> "This language isn't available for voice input right now. " +
            "Pick another language in Settings, or go online."
        else -> "Voice input failed (code $code)."
    }
}
