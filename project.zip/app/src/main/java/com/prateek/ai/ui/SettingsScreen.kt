package com.prateek.ai.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prateek.ai.data.AiPresets
import com.prateek.ai.data.Languages
import com.prateek.ai.data.Settings
import com.prateek.ai.ui.theme.Pk

@Composable
fun SettingsScreen(
    state: UiState,
    onSave: (Settings) -> Unit,
    onTestAi: (Settings) -> Unit,
    onTestVoice: (Settings) -> Unit,
    onBack: () -> Unit
) {
    var draft by remember { mutableStateOf(state.settings) }
    var showKey by remember { mutableStateOf(false) }
    var urlError by remember { mutableStateOf<String?>(null) }

    fun cleaned(d: Settings) = d.copy(
        assistantName = d.assistantName.trim().ifEmpty { "Prateek AI" },
        baseUrl = d.baseUrl.trim(),
        model = d.model.trim(),
        apiKey = d.apiKey.trim()
    )

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Settings", onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionLabel("Assistant")
            OutlinedTextField(
                value = draft.assistantName,
                onValueChange = { draft = draft.copy(assistantName = it) },
                label = { Text("Assistant name") },
                singleLine = true,
                colors = pkFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )

            SectionLabel("Language")
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Languages.all.forEach { (tag, label) ->
                    ChoiceChip(label, draft.language == tag) { draft = draft.copy(language = tag) }
                }
            }
            Text(
                "Used for voice input and for the spoken voice. Hindi needs a Hindi voice installed on the phone.",
                color = Pk.TextDim,
                fontSize = 12.sp
            )

            SectionLabel("Voice")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Speak replies aloud", color = Pk.Text, modifier = Modifier.weight(1f))
                Switch(
                    checked = draft.speakReplies,
                    onCheckedChange = { draft = draft.copy(speakReplies = it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Pk.Bg,
                        checkedTrackColor = Pk.Blue
                    )
                )
            }
            Text("Voice speed", color = Pk.Text)
            Slider(
                value = draft.speechRate,
                onValueChange = { draft = draft.copy(speechRate = it) },
                valueRange = 0.5f..1.5f,
                colors = SliderDefaults.colors(
                    thumbColor = Pk.Blue,
                    activeTrackColor = Pk.Blue,
                    inactiveTrackColor = Pk.SurfaceHigh
                )
            )
            OutlinedButton(onClick = { onTestVoice(draft) }) { Text("Test voice", color = Pk.Blue) }
            state.voiceMessage?.let { Text(it, color = Pk.TextDim, fontSize = 13.sp) }

            SectionLabel("AI endpoint")
            Text(
                "Any service with an OpenAI-style chat API works. Pick a preset, then paste your own free API key. " +
                    "Model names change over time; if you see a 404, check your provider's model list.",
                color = Pk.TextDim,
                fontSize = 12.sp
            )
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AiPresets.all.forEach { p ->
                    ChoiceChip(p.label, draft.baseUrl == p.baseUrl) {
                        draft = draft.copy(baseUrl = p.baseUrl, model = p.model)
                    }
                }
            }
            OutlinedTextField(
                value = draft.baseUrl,
                onValueChange = { draft = draft.copy(baseUrl = it); urlError = null },
                label = { Text("Base URL (https://…)") },
                singleLine = true,
                colors = pkFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = draft.model,
                onValueChange = { draft = draft.copy(model = it) },
                label = { Text("Model name") },
                singleLine = true,
                colors = pkFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = draft.apiKey,
                onValueChange = { draft = draft.copy(apiKey = it) },
                label = { Text("API key") },
                singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    TextButton(onClick = { showKey = !showKey }) {
                        Text(if (showKey) "Hide" else "Show", color = Pk.Blue)
                    }
                },
                colors = pkFieldColors(),
                modifier = Modifier.fillMaxWidth()
            )
            urlError?.let { Text(it, color = Pk.Error, fontSize = 13.sp) }

            OutlinedButton(
                enabled = !state.aiTesting,
                onClick = { onTestAi(cleaned(draft)) }
            ) { Text(if (state.aiTesting) "Testing…" else "Test connection", color = Pk.Blue) }
            state.aiTestMessage?.let { Text(it, color = Pk.Text, fontSize = 13.sp) }

            Button(
                onClick = {
                    val c = cleaned(draft)
                    if (c.baseUrl.isNotEmpty() && !c.baseUrl.startsWith("https://")) {
                        urlError = "The base URL must start with https://"
                    } else {
                        onSave(c)
                        onBack()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Pk.Blue, contentColor = Pk.Bg),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save settings") }
        }
    }
}
