package com.prateek.ai.data

data class Settings(
    val assistantName: String = "Prateek AI",
    val language: String = "hi-IN",
    val speakReplies: Boolean = true,
    val speechRate: Float = 1.0f,
    val baseUrl: String = "",
    val model: String = "",
    val apiKey: String = ""
) {
    val isAiConfigured: Boolean
        get() = baseUrl.isNotBlank() && model.isNotBlank() && apiKey.isNotBlank()
}

object AiPresets {
    data class Preset(val label: String, val baseUrl: String, val model: String)

    // Model names change over time. If you get a 404, check your provider's model list.
    val all = listOf(
        Preset("Gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.0-flash"),
        Preset("Groq", "https://api.groq.com/openai/v1", "llama-3.1-8b-instant"),
        Preset("OpenRouter", "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct:free")
    )
}

object Languages {
    val all = listOf(
        "hi-IN" to "Hindi",
        "en-IN" to "English (India)",
        "en-US" to "English (US)"
    )
}
