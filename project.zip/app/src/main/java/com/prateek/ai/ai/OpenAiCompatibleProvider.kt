package com.prateek.ai.ai

import com.prateek.ai.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Talks to any service that offers an OpenAI-style /chat/completions endpoint. */
class OpenAiCompatibleProvider(
    private val client: OkHttpClient = defaultClient()
) : AiProvider {

    override suspend fun chat(config: AiConfig, history: List<ChatMessage>): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val base = config.baseUrl.trim().trimEnd('/')
                if (!base.startsWith("https://")) {
                    return@withContext Result.failure(
                        AiException("The endpoint must start with https://")
                    )
                }
                val json = OpenAiJson.buildRequest(config.model.trim(), config.systemPrompt, history)
                val request = Request.Builder()
                    .url("$base/chat/completions")
                    .header("Authorization", "Bearer ${config.apiKey.trim()}")
                    .post(json.toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .build()

                client.newCall(request).execute().use { response ->
                    val text = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withContext Result.failure(AiException(messageForHttp(response.code)))
                    }
                    val reply = OpenAiJson.parseReply(text)
                        ?: return@withContext Result.failure(
                            AiException("The AI sent back an empty or unreadable answer.")
                        )
                    Result.success(reply)
                }
            } catch (e: IllegalArgumentException) {
                Result.failure(AiException("The endpoint URL or API key has an invalid character."))
            } catch (e: IOException) {
                Result.failure(AiException("Network error. Check your internet and the endpoint address."))
            }
        }

    companion object {
        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .callTimeout(60, TimeUnit.SECONDS)
            .build()

        fun messageForHttp(code: Int): String = when (code) {
            400 -> "The AI rejected the request. Check the model name (HTTP 400)."
            401, 403 -> "The API key is wrong, expired or not allowed (HTTP $code)."
            404 -> "Endpoint or model name looks wrong (HTTP 404)."
            429 -> "Free limit reached or too many requests. Try again in a while (HTTP 429)."
            in 500..599 -> "The AI service has a problem right now (HTTP $code). Try later."
            else -> "The AI request failed (HTTP $code)."
        }
    }
}
