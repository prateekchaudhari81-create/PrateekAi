package com.prateek.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prateek.ai.ui.theme.Pk

private val SUGGESTIONS = listOf(
    "YouTube kholo",
    "Time kya hai?",
    "5 minute ka timer",
    "Alarm 7:30 am"
)

@Composable
fun ChatScreen(
    state: UiState,
    onMic: () -> Unit,
    onSend: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onDismissNotice: () -> Unit
) {
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(state.messages.size) {
        if (state.messages.isNotEmpty()) listState.animateScrollToItem(state.messages.lastIndex)
    }

    fun submit() {
        val text = input.trim()
        if (text.isNotEmpty()) {
            onSend(text)
            input = ""
        }
    }

    val caption = when (state.phase) {
        Phase.LISTENING -> state.partialText.ifBlank { "Listening…" }
        Phase.THINKING -> "Thinking…"
        else -> ""
    }

    Column(Modifier.fillMaxSize()) {
        // Header
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 8.dp, top = 10.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    state.settings.assistantName,
                    color = Pk.Text,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = 1.5.sp
                )
                Spacer(Modifier.height(6.dp))
                StatusPill(online = state.online, phase = state.phase)
            }
            TextButton(onClick = onOpenPrivacy) { Text("Privacy", color = Pk.Blue) }
            TextButton(onClick = onOpenSettings) { Text("Settings", color = Pk.Blue) }
        }

        Waveform(
            level = state.level,
            phase = state.phase,
            modifier = Modifier
                .fillMaxWidth()
                .height(84.dp)
                .padding(horizontal = 16.dp)
        )
        Text(
            caption,
            color = Pk.TextDim,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
            maxLines = 1,
            modifier = Modifier
                .fillMaxWidth()
                .height(24.dp)
                .padding(horizontal = 24.dp)
        )

        // Chat history
        if (state.messages.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Tap the mic, type, or try one of these", color = Pk.TextDim, fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    SUGGESTIONS.forEach { s ->
                        ChoiceChip(label = s, selected = false) { onSend(s) }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(state.messages, key = { it.id }) { MessageBubble(it) }
            }
        }

        // Notice banner
        val notice = state.notice
        if (notice != null) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(notice, color = Pk.Text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = onDismissNotice) { Text("Dismiss", color = Pk.Blue) }
            }
        }

        // Input row
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Type or tap the mic", color = Pk.TextDim) },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = pkFieldColors(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { submit() })
            )
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                if (input.isBlank()) {
                    MicButton(phase = state.phase, onClick = onMic)
                } else {
                    SendButton(onClick = { submit() })
                }
            }
        }
    }
}
