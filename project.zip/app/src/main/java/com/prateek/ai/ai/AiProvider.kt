package com.prateek.ai.ai

import com.prateek.ai.model.ChatMessage

data class AiConfig(
    val baseUrl: String,
    val model: String,
    val apiKey: String,
    val systemPrompt: String
)

class AiException(val userMessage: String) : Exception(userMessage)

interface AiProvider {
    suspend fun chat(config: AiConfig, history: List<ChatMessage>): Result<String>
}
