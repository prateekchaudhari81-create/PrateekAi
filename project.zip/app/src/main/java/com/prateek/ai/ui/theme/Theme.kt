package com.prateek.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Pk {
    val Bg = Color(0xFF05070D)
    val Surface = Color(0xFF0B1220)
    val SurfaceHigh = Color(0xFF121D33)
    val Blue = Color(0xFF2EA8FF)
    val BlueDim = Color(0xFF1B6FB3)
    val Text = Color(0xFFE6F1FF)
    val TextDim = Color(0xFF8AA0BC)
    val Error = Color(0xFFFF5A6A)
    val Ok = Color(0xFF35E0A1)
}

private val Scheme = darkColorScheme(
    primary = Pk.Blue,
    onPrimary = Pk.Bg,
    background = Pk.Bg,
    onBackground = Pk.Text,
    surface = Pk.Surface,
    onSurface = Pk.Text,
    surfaceVariant = Pk.SurfaceHigh,
    onSurfaceVariant = Pk.TextDim,
    error = Pk.Error,
    outline = Pk.BlueDim
)

@Composable
fun PrateekTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
