package com.prateek.ai.ai

import com.prateek.ai.model.ChatMessage
import com.prateek.ai.model.Role
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

object OpenAiJson {

    fun buildRequest(model: String, systemPrompt: String, history: List<ChatMessage>): String {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt))
        for (m in history) {
            val role = if (m.role == Role.USER) "user" else "assistant"
            messages.put(JSONObject().put("role", role).put("content", m.text))
        }
        return JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("temperature", 0.6)
            .toString()
    }

    fun parseReply(body: String): String? {
        return try {
            val choices = JSONObject(body).optJSONArray("choices")
            if (choices == null || choices.length() == 0) {
                null
            } else {
                val content = choices.getJSONObject(0)
                    .optJSONObject("message")
                    ?.optString("content", "")
                content?.trim()?.takeIf { it.isNotEmpty() }
            }
        } catch (e: JSONException) {
            null
        }
    }
}
