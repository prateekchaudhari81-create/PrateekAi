package com.prateek.ai.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Wraps Android TextToSpeech. Call from the main thread. */
class SpeechOutput(
    context: Context,
    private val onSpeakingChanged: (Boolean) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var initFailed = false
    private var pending: Triple<String, String, Float>? = null
    private var counter = 0

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        postSpeaking(true)
                    }

                    override fun onDone(utteranceId: String?) {
                        postSpeaking(false)
                    }

                    override fun onError(utteranceId: String?) {
                        postSpeaking(false)
                    }
                })
                ready = true
                val p = pending
                pending = null
                if (p != null) speak(p.first, p.second, p.third)
            } else {
                initFailed = true
            }
        }
    }

    /** Returns a warning message if speaking is not possible, otherwise null. */
    fun speak(text: String, languageTag: String, rate: Float): String? {
        val engine = tts
        if (initFailed || engine == null) {
            return "Text-to-speech is not available on this phone."
        }
        if (!ready) {
            pending = Triple(text, languageTag, rate)
            return null
        }
        val clean = cleanForSpeech(text)
        if (clean.isBlank()) return null
        val result = engine.setLanguage(Locale.forLanguageTag(languageTag))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            return "This phone has no voice for the selected language. " +
                "Install one in Android Settings > Text-to-speech."
        }
        engine.setSpeechRate(rate)
        counter++
        engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "pk-$counter")
        return null
    }

    fun stop() {
        tts?.stop()
        postSpeaking(false)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    private fun postSpeaking(value: Boolean) {
        main.post { onSpeakingChanged(value) }
    }

    private fun cleanForSpeech(text: String): String =
        text.replace(Regex("[*_`#>]+"), " ").replace(Regex("\\s+"), " ").trim()
}
