package com.prateek.ai.command

import java.util.Locale

/** Turns a sentence into a local command, or null if it should go to the AI instead. */
object CommandParser {

    private val openWords = listOf(
        "open", "launch", "start", "kholo", "khol", "chalu",
        "खोलो", "खोल", "ओपन", "चालू"
    )
    private val wifiAliases = listOf("wifi", "wi-fi", "wi fi", "वाईफाई", "वाई-फाई", "वाई फाई")
    private val settingsAliases = listOf("settings", "setting", "सेटिंग")

    private val timeQueries = listOf(
        "what time is it", "what's the time", "what is the time", "current time",
        "tell me the time", "time kya", "time batao", "abhi time",
        "kitne baje", "kitna baja", "कितने बजे", "टाइम क्या", "टाइम बताओ",
        "समय क्या", "समय बताओ"
    )
    private val dateQueries = listOf(
        "what date", "today's date", "what day is it", "aaj ki date", "date kya",
        "aaj ki tarikh", "tarikh kya", "aaj kaun sa din",
        "आज की तारीख", "तारीख क्या", "आज कौन सा दिन"
    )

    private val timerRegex = Regex(
        """(\d{1,4})\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?|ghante|ghanta|सेकंड|सेकेंड|मिनट|घंटे|घंटा)"""
    )
    private val clockRegex = Regex("""(\d{1,2})(?:[:.](\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?""")

    private val pmHints = listOf("shaam", "raat", "evening", "night", "dopahar", "afternoon", "शाम", "रात", "दोपहर")
    private val amHints = listOf("subah", "morning", "सुबह")

    fun parse(raw: String): Command? {
        val t = raw.lowercase(Locale.ROOT).trim()
        if (t.isEmpty()) return null
        val words = t.split(Regex("\\s+")).size

        parseTimer(t)?.let { return it }
        parseAlarm(t)?.let { return it }
        if (words <= 6 && timeQueries.any { t.contains(it) }) return Command.TellTime
        if (words <= 6 && dateQueries.any { t.contains(it) }) return Command.TellDate
        if (words <= 7) parseOpen(t)?.let { return it }
        return null
    }

    private fun parseTimer(t: String): Command? {
        if (!(t.contains("timer") || t.contains("टाइमर"))) return null
        val m = timerRegex.find(t) ?: return Command.Clarify(ClarifyKind.TIMER_DURATION)
        val value = m.groupValues[1].toInt()
        val unit = m.groupValues[2]
        val multiplier = when {
            unit.startsWith("sec") || unit.startsWith("सेक") -> 1
            unit.startsWith("min") || unit.startsWith("मिनट") -> 60
            else -> 3600
        }
        val total = value * multiplier
        if (total !in 1..86400) return Command.Clarify(ClarifyKind.INVALID_TIMER)
        return Command.SetTimer(total)
    }

    private fun parseAlarm(t: String): Command? {
        if (!(t.contains("alarm") || t.contains("अलार्म"))) return null
        val m = clockRegex.find(t) ?: return Command.Clarify(ClarifyKind.ALARM_TIME)
        val h = m.groupValues[1].toInt()
        val minute = m.groupValues[2].ifEmpty { "0" }.toInt()
        if (h > 23 || minute > 59) return Command.Clarify(ClarifyKind.INVALID_ALARM_TIME)

        val suffix = m.groupValues[3].firstOrNull()
        val isPm = suffix == 'p' || (suffix == null && pmHints.any { t.contains(it) })
        val isAm = suffix == 'a' || (suffix == null && amHints.any { t.contains(it) })

        var hour = h
        if (isPm && hour in 1..11) {
            hour += 12
        } else if (isAm && hour == 12) {
            hour = 0
        }
        return Command.SetAlarm(hour, minute)
    }

    private fun parseOpen(t: String): Command? {
        if (openWords.none { t.contains(it) }) return null
        if (wifiAliases.any { t.contains(it) }) return Command.OpenSystemSettings(SystemSettingsKind.WIFI)
        if (settingsAliases.any { t.contains(it) }) return Command.OpenSystemSettings(SystemSettingsKind.GENERAL)
        val app = KnownApp.values().firstOrNull { a -> a.aliases.any { t.contains(it) } }
        return app?.let { Command.OpenApp(it) }
    }
}
