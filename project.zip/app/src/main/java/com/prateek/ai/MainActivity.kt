package com.prateek.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.prateek.ai.ui.ChatViewModel
import com.prateek.ai.ui.PrateekApp
import com.prateek.ai.ui.theme.PrateekTheme

class MainActivity : ComponentActivity() {

    private val vm: ChatViewModel by viewModels()
    private var micGranted by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        micGranted = hasMicPermission()
        setContent {
            PrateekTheme {
                PrateekApp(
                    vm = vm,
                    micGranted = micGranted,
                    onMicPermissionResult = { micGranted = it },
                    openAppSettings = ::openAppSettings
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        micGranted = hasMicPermission()
    }

    override fun onStop() {
        super.onStop()
        vm.onAppStopped()
    }

    private fun hasMicPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun openAppSettings() {
        startActivity(
            Intent(
                android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", packageName, null)
            )
        )
    }
}
