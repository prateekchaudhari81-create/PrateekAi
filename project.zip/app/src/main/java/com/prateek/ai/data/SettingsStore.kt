package com.prateek.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SettingsStore(context: Context) {

    private val plain: SharedPreferences =
        context.getSharedPreferences("prateek_settings", Context.MODE_PRIVATE)

    // The API key goes in encrypted storage. If this phone cannot create it,
    // the key is kept in memory only (never written to disk in plain text).
    private val secure: SharedPreferences? = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "prateek_secure",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        null
    }

    private var keyInMemory: String = ""

    val keyStoredSecurely: Boolean get() = secure != null

    fun load(): Settings {
        val d = Settings()
        return Settings(
            assistantName = plain.getString(K_NAME, d.assistantName) ?: d.assistantName,
            language = plain.getString(K_LANG, d.language) ?: d.language,
            speakReplies = plain.getBoolean(K_SPEAK, d.speakReplies),
            speechRate = plain.getFloat(K_RATE, d.speechRate).coerceIn(0.5f, 1.5f),
            baseUrl = plain.getString(K_URL, d.baseUrl) ?: d.baseUrl,
            model = plain.getString(K_MODEL, d.model) ?: d.model,
            apiKey = secure?.getString(K_KEY, "") ?: keyInMemory
        )
    }

    fun save(s: Settings) {
        plain.edit()
            .putString(K_NAME, s.assistantName)
            .putString(K_LANG, s.language)
            .putBoolean(K_SPEAK, s.speakReplies)
            .putFloat(K_RATE, s.speechRate)
            .putString(K_URL, s.baseUrl)
            .putString(K_MODEL, s.model)
            .apply()
        val sec = secure
        if (sec != null) {
            sec.edit().putString(K_KEY, s.apiKey).apply()
        } else {
            keyInMemory = s.apiKey
        }
    }

    private companion object {
        const val K_NAME = "assistant_name"
        const val K_LANG = "language"
        const val K_SPEAK = "speak_replies"
        const val K_RATE = "speech_rate"
        const val K_URL = "base_url"
        const val K_MODEL = "model"
        const val K_KEY = "api_key"
    }
}
