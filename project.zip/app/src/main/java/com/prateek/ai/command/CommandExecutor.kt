package com.prateek.ai.command

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Runs a parsed command and returns an honest one-line report. */
class CommandExecutor(private val context: Context) {

    fun execute(cmd: Command, hindi: Boolean): String = when (cmd) {
        is Command.OpenApp -> openApp(cmd.app, hindi)
        is Command.OpenSystemSettings -> openSettings(cmd.kind, hindi)
        Command.TellTime -> {
            val time = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())
            if (hindi) "अभी समय $time है।" else "It's $time."
        }
        Command.TellDate -> {
            val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
            if (hindi) "आज की तारीख $date है।" else "Today is $date."
        }
        is Command.SetTimer -> setTimer(cmd.seconds, hindi)
        is Command.SetAlarm -> setAlarm(cmd.hour, cmd.minute, hindi)
        is Command.Clarify -> clarify(cmd.kind, hindi)
    }

    private fun startSafely(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }

    private fun openApp(app: KnownApp, hindi: Boolean): String {
        val launch = context.packageManager.getLaunchIntentForPackage(app.packageName)
        if (launch != null && startSafely(launch)) {
            return if (hindi) "${app.label} खोल रहा हूँ।" else "Opening ${app.label}."
        }
        val web = Intent(Intent.ACTION_VIEW, Uri.parse(app.webUrl))
        return if (startSafely(web)) {
            if (hindi) "${app.label} फ़ोन में नहीं मिला, उसकी वेबसाइट खोल रहा हूँ।"
            else "${app.label} isn't installed, so I'm opening its website."
        } else {
            if (hindi) "इस फ़ोन में ${app.label} नहीं खुल सका।"
            else "I couldn't open ${app.label} on this phone."
        }
    }

    private fun openSettings(kind: SystemSettingsKind, hindi: Boolean): String {
        val action = when (kind) {
            SystemSettingsKind.WIFI -> android.provider.Settings.ACTION_WIFI_SETTINGS
            SystemSettingsKind.GENERAL -> android.provider.Settings.ACTION_SETTINGS
        }
        val name = if (kind == SystemSettingsKind.WIFI) {
            if (hindi) "वाई-फ़ाई सेटिंग्स" else "Wi-Fi settings"
        } else {
            if (hindi) "सेटिंग्स" else "Settings"
        }
        return if (startSafely(Intent(action))) {
            if (hindi) "$name खोल रहा हूँ।" else "Opening $name."
        } else {
            if (hindi) "$name नहीं खुल सकीं।" else "I couldn't open $name."
        }
    }

    private fun setTimer(seconds: Int, hindi: Boolean): String {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Prateek AI")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        val d = describeDuration(seconds, hindi)
        return if (startSafely(intent)) {
            if (hindi) "मैंने क्लॉक ऐप से $d का टाइमर शुरू करने को कहा है। कृपया देख लें कि वह चल रहा है।"
            else "I asked the Clock app to start a $d timer. Please check that it is running."
        } else {
            if (hindi) "इस फ़ोन में टाइमर के लिए क्लॉक ऐप नहीं मिला।"
            else "I couldn't find a Clock app to set the timer."
        }
    }

    private fun setAlarm(hour: Int, minute: Int, hindi: Boolean): String {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Prateek AI")
        val hhmm = String.format(Locale.ENGLISH, "%02d:%02d", hour, minute)
        return if (startSafely(intent)) {
            if (hindi) "मैंने क्लॉक ऐप से $hhmm का अलार्म सेट करने को कहा है। कृपया क्लॉक ऐप में पक्का कर लें।"
            else "I asked the Clock app to set an alarm for $hhmm. Please confirm it in the Clock app."
        } else {
            if (hindi) "इस फ़ोन में अलार्म के लिए क्लॉक ऐप नहीं मिला।"
            else "I couldn't find a Clock app to set the alarm."
        }
    }

    private fun clarify(kind: ClarifyKind, hindi: Boolean): String = when (kind) {
        ClarifyKind.TIMER_DURATION ->
            if (hindi) "कितनी देर का टाइमर? जैसे: 5 मिनट का टाइमर।"
            else "How long should the timer be? For example: 5 minute timer."
        ClarifyKind.INVALID_TIMER ->
            if (hindi) "टाइमर 1 सेकंड से 24 घंटे के बीच होना चाहिए।"
            else "A timer must be between 1 second and 24 hours."
        ClarifyKind.ALARM_TIME ->
            if (hindi) "किस समय का अलार्म? जैसे: अलार्म 7:30 am।"
            else "What time should the alarm be? For example: alarm 7:30 am."
        ClarifyKind.INVALID_ALARM_TIME ->
            if (hindi) "वह समय सही नहीं लगा। जैसे बोलें: अलार्म 7:30 am।"
            else "That time doesn't look right. Try: alarm 7:30 am."
    }

    private fun describeDuration(sec: Int, hindi: Boolean): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        val parts = mutableListOf<String>()
        if (h > 0) parts.add(if (hindi) "$h घंटे" else if (h == 1) "1 hour" else "$h hours")
        if (m > 0) parts.add(if (hindi) "$m मिनट" else if (m == 1) "1 minute" else "$m minutes")
        if (s > 0) parts.add(if (hindi) "$s सेकंड" else if (s == 1) "1 second" else "$s seconds")
        return parts.joinToString(" ")
    }
}
