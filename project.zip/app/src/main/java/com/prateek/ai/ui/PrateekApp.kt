package com.prateek.ai.ui

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private enum class Screen { CHAT, SETTINGS, PRIVACY }

@Composable
fun PrateekApp(
    vm: ChatViewModel,
    micGranted: Boolean,
    onMicPermissionResult: (Boolean) -> Unit,
    openAppSettings: () -> Unit
) {
    val state by vm.state.collectAsStateWithLifecycle()
    var screen by rememberSaveable { mutableStateOf(Screen.CHAT) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        onMicPermissionResult(granted)
        if (granted) {
            vm.toggleListening()
        } else {
            vm.showNotice("Microphone permission is off. Allow it from Privacy to use voice. You can still type.")
        }
    }

    val onMic: () -> Unit = {
        if (micGranted) vm.toggleListening()
        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    BackHandler(enabled = screen != Screen.CHAT) { screen = Screen.CHAT }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF060A14), Color(0xFF04060B))))
            .systemBarsPadding()
            .imePadding()
    ) {
        when (screen) {
            Screen.CHAT -> ChatScreen(
                state = state,
                onMic = onMic,
                onSend = vm::sendText,
                onOpenSettings = { screen = Screen.SETTINGS },
                onOpenPrivacy = { screen = Screen.PRIVACY },
                onDismissNotice = vm::dismissNotice
            )
            Screen.SETTINGS -> SettingsScreen(
                state = state,
                onSave = vm::saveSettings,
                onTestAi = vm::testConnection,
                onTestVoice = vm::testVoice,
                onBack = { screen = Screen.CHAT }
            )
            Screen.PRIVACY -> PrivacyScreen(
                micGranted = micGranted,
                keyStoredSecurely = state.keyStoredSecurely,
                onOpenAppSettings = openAppSettings,
                onClearChat = vm::clearChat,
                onBack = { screen = Screen.CHAT }
            )
        }
    }
}
