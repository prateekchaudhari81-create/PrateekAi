package com.prateek.ai.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prateek.ai.ui.theme.Pk

@Composable
private fun InfoBlock(title: String, body: String, titleColor: androidx.compose.ui.graphics.Color = Pk.Text) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = titleColor, fontSize = 15.sp)
        Text(body, color = Pk.TextDim, fontSize = 13.sp, lineHeight = 19.sp)
    }
}

@Composable
fun PrivacyScreen(
    micGranted: Boolean,
    keyStoredSecurely: Boolean,
    onOpenAppSettings: () -> Unit,
    onClearChat: () -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Permissions and privacy", onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            SectionLabel("Permissions")
            InfoBlock(
                title = if (micGranted) "Microphone: allowed" else "Microphone: not allowed",
                titleColor = if (micGranted) Pk.Ok else Pk.Error,
                body = "Used only after you tap the mic button. Your phone's speech service turns speech into " +
                    "text, and it may send the audio to its servers when you are online."
            )
            OutlinedButton(onClick = onOpenAppSettings) { Text("Open app permission settings", color = Pk.Blue) }
            InfoBlock(
                "Internet",
                "Used only to talk to the AI endpoint you set in Settings. A message leaves the phone only " +
                    "when it is not a local command."
            )
            InfoBlock(
                "Alarm access",
                "Lets the app ask your Clock app to set an alarm or timer. The Clock app does the actual work, " +
                    "so check it to confirm."
            )

            SectionLabel("Your data")
            InfoBlock(
                "Local commands stay on the phone",
                "Opening apps, time, date, alarm and timer never go to the internet."
            )
            InfoBlock(
                "What the AI endpoint receives",
                "The text of your message and the last few messages of this chat, sent to the service you chose. " +
                    "That service's own privacy rules apply."
            )
            InfoBlock(
                "API key",
                if (keyStoredSecurely) {
                    "Stored on this phone, encrypted with Android Keystore. It is not inside the APK."
                } else {
                    "Secure storage is not available on this phone, so the key is kept only until the app closes."
                }
            )
            InfoBlock(
                "Chat history",
                "Kept in memory only and gone when the app closes."
            )
            OutlinedButton(onClick = onClearChat) { Text("Clear chat now", color = Pk.Blue) }

            SectionLabel("Not available yet")
            InfoBlock(
                "Wake word \"Hello Prateek\"",
                "Not built. For now, tap the mic and keep the app open. Always-on listening needs a background " +
                    "service, uses more battery, and may be stopped by the phone's battery saver. It will be " +
                    "added only after testing on a real device."
            )
            InfoBlock(
                "Confirmation for risky actions",
                "This version has no risky actions: no sending messages, deleting files, publishing or purchases. " +
                    "When those are added, the app will ask first."
            )
        }
    }
}
