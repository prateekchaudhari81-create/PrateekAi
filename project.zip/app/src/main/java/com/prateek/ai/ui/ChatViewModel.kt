package com.prateek.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.prateek.ai.ai.AiConfig
import com.prateek.ai.ai.AiException
import com.prateek.ai.ai.AiProvider
import com.prateek.ai.ai.OpenAiCompatibleProvider
import com.prateek.ai.command.CommandExecutor
import com.prateek.ai.command.CommandParser
import com.prateek.ai.data.Settings
import com.prateek.ai.data.SettingsStore
import com.prateek.ai.model.ChatMessage
import com.prateek.ai.model.Role
import com.prateek.ai.net.ConnectivityMonitor
import com.prateek.ai.voice.SpeechOutput
import com.prateek.ai.voice.VoiceInput
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING }

data class UiState(
    val messages: List<ChatMessage> = emptyList(),
    val settings: Settings = Settings(),
    val online: Boolean = true,
    val listening: Boolean = false,
    val thinking: Boolean = false,
    val speaking: Boolean = false,
    val partialText: String = "",
    val level: Float = 0f,
    val notice: String? = null,
    val aiTesting: Boolean = false,
    val aiTestMessage: String? = null,
    val voiceMessage: String? = null,
    val keyStoredSecurely: Boolean = true
) {
    val phase: Phase
        get() = when {
            listening -> Phase.LISTENING
            thinking -> Phase.THINKING
            speaking -> Phase.SPEAKING
            else -> Phase.IDLE
        }
}

class ChatViewModel(app: Application) : AndroidViewModel(app), VoiceInput.Listener {

    private val store = SettingsStore(app)
    private val provider: AiProvider = OpenAiCompatibleProvider()
    private val executor = CommandExecutor(app)
    private val connectivity = ConnectivityMonitor(app)

    private val _state = MutableStateFlow(
        UiState(
            settings = store.load(),
            online = connectivity.online.value,
            keyStoredSecurely = store.keyStoredSecurely
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val voice = VoiceInput(app, this)
    private val speech = SpeechOutput(app) { speaking ->
        _state.update { it.copy(speaking = speaking) }
    }

    private var aiJob: Job? = null
    private var nextId = 1L

    init {
        connectivity.start()
        viewModelScope.launch {
            connectivity.online.collect { online ->
                _state.update { it.copy(online = online) }
            }
        }
    }

    // ---- Voice input ----

    fun toggleListening() {
        val s = _state.value
        if (s.listening) {
            voice.stopListening()
            return
        }
        speech.stop()
        aiJob?.cancel()
        _state.update {
            it.copy(thinking = false, speaking = false, partialText = "", level = 0f, notice = null)
        }
        voice.start(s.settings.language, preferOffline = !s.online)
    }

    override fun onListening() {
        _state.update { it.copy(listening = true) }
    }

    override fun onLevel(level: Float) {
        _state.update { it.copy(level = level) }
    }

    override fun onPartial(text: String) {
        _state.update { it.copy(partialText = text) }
    }

    override fun onResult(text: String) {
        _state.update { it.copy(listening = false, level = 0f, partialText = "") }
        handleUserText(text)
    }

    override fun onError(message: String) {
        _state.update {
            it.copy(listening = false, level = 0f, partialText = "", notice = message)
        }
    }

    // ---- Text and routing ----

    fun sendText(text: String) {
        handleUserText(text)
    }

    private fun handleUserText(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        val settings = _state.value.settings
        val hindi = settings.language.startsWith("hi")
        addMessage(Role.USER, text)

        val command = CommandParser.parse(text)
        if (command != null) {
            val reply = executor.execute(command, hindi)
            addMessage(Role.ASSISTANT, reply)
            speakIfEnabled(reply)
            return
        }

        if (!_state.value.online) {
            val reply = if (hindi) {
                "आप ऑफ़लाइन हैं, इसलिए अभी सिर्फ़ लोकल कमांड चलेंगे: ऐप खोलना, समय, तारीख, अलार्म और टाइमर।"
            } else {
                "You're offline, so only local commands work right now: open apps, time, date, alarm and timer."
            }
            addMessage(Role.ASSISTANT, reply)
            speakIfEnabled(reply)
            return
        }

        if (!settings.isAiConfigured) {
            val reply = if (hindi) {
                "AI एंडपॉइंट अभी सेट नहीं है। सेटिंग्स में एंडपॉइंट, मॉडल और API की डालें। लोकल कमांड फिर भी चलेंगे।"
            } else {
                "The AI endpoint isn't set up yet. Open Settings and add an endpoint, model and API key. Local commands still work."
            }
            addMessage(Role.ASSISTANT, reply)
            speakIfEnabled(reply)
            return
        }

        aiJob?.cancel()
        _state.update { it.copy(thinking = true, notice = null) }
        val history = _state.value.messages.filter { !it.isError }.takeLast(12)
        aiJob = viewModelScope.launch {
            val result = provider.chat(configFor(settings), history)
            result
                .onSuccess { reply ->
                    addMessage(Role.ASSISTANT, reply)
                    speakIfEnabled(reply)
                }
                .onFailure { e ->
                    val msg = (e as? AiException)?.userMessage
                        ?: "Something went wrong while contacting the AI."
                    addMessage(Role.ASSISTANT, msg, isError = true)
                }
            _state.update { it.copy(thinking = false) }
        }
    }

    private fun configFor(s: Settings) = AiConfig(
        baseUrl = s.baseUrl,
        model = s.model,
        apiKey = s.apiKey,
        systemPrompt = "You are ${s.assistantName}, a concise voice assistant inside an Android app. " +
            "Answer in the same language the user writes in (Hindi, Hinglish or English) and keep " +
            "replies short, ideally under 60 words, because they are read aloud. You cannot control " +
            "the phone, send messages, browse the web or set reminders yourself; the app handles a few " +
            "local commands separately. Never claim to have performed an action. If you are unsure, say so."
    )

    private fun addMessage(role: Role, text: String, isError: Boolean = false) {
        val id = nextId++
        _state.update { it.copy(messages = it.messages + ChatMessage(id, role, text, isError)) }
    }

    private fun speakIfEnabled(text: String) {
        val s = _state.value.settings
        if (!s.speakReplies) return
        val warning = speech.speak(text, s.language, s.speechRate)
        if (warning != null) showNotice(warning)
    }

    // ---- Settings and misc ----

    fun saveSettings(s: Settings) {
        store.save(s)
        _state.update {
            it.copy(settings = s, notice = null, keyStoredSecurely = store.keyStoredSecurely)
        }
    }

    fun testConnection(draft: Settings) {
        if (!draft.isAiConfigured) {
            _state.update { it.copy(aiTestMessage = "Fill in the endpoint, model and API key first.") }
            return
        }
        _state.update { it.copy(aiTesting = true, aiTestMessage = null) }
        viewModelScope.launch {
            val probe = listOf(ChatMessage(0, Role.USER, "Reply with the single word: ready"))
            val result = provider.chat(configFor(draft), probe)
            val message = result.fold(
                onSuccess = { "Connected. The AI replied." },
                onFailure = { e -> (e as? AiException)?.userMessage ?: "Connection failed." }
            )
            _state.update { it.copy(aiTesting = false, aiTestMessage = message) }
        }
    }

    fun testVoice(draft: Settings) {
        val sample = if (draft.language.startsWith("hi")) {
            "नमस्ते, मैं ${draft.assistantName} हूँ।"
        } else {
            "Hello, I am ${draft.assistantName}."
        }
        val warning = speech.speak(sample, draft.language, draft.speechRate)
        _state.update { it.copy(voiceMessage = warning) }
    }

    fun clearChat() {
        aiJob?.cancel()
        speech.stop()
        _state.update { it.copy(messages = emptyList(), thinking = false) }
    }

    fun showNotice(message: String) {
        _state.update { it.copy(notice = message) }
    }

    fun dismissNotice() {
        _state.update { it.copy(notice = null) }
    }

    fun onAppStopped() {
        voice.destroy()
        speech.stop()
        _state.update { it.copy(listening = false, level = 0f, partialText = "") }
    }

    override fun onCleared() {
        connectivity.stop()
        voice.destroy()
        speech.shutdown()
        super.onCleared()
    }
}
