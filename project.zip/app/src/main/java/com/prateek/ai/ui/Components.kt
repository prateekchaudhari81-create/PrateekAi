package com.prateek.ai.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.prateek.ai.model.ChatMessage
import com.prateek.ai.model.Role
import com.prateek.ai.ui.theme.Pk
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * Animated bars. While listening the bars follow the real microphone level.
 * While speaking, Android gives no audio level, so the motion is decorative only.
 */
@Composable
fun Waveform(level: Float, phase: Phase, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "wave")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing)),
        label = "t"
    )
    val smoothLevel by animateFloatAsState(level, tween(120), label = "level")

    Canvas(modifier) {
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(
                    Pk.Blue.copy(alpha = 0.08f + 0.14f * smoothLevel),
                    Color.Transparent
                ),
                center = center,
                radius = size.width / 2f
            )
        )
        val bars = 31
        val gap = size.width / bars
        val barW = gap * 0.45f
        val midY = size.height / 2f
        val minH = 4.dp.toPx()
        for (i in 0 until bars) {
            val x = gap * (i + 0.5f)
            val envelope = 1f - abs(i - (bars - 1) / 2f) / ((bars - 1) / 2f) * 0.75f
            val wave = (sin(t + i * 0.5f) + 1f) / 2f
            val amp = when (phase) {
                Phase.IDLE -> 0.05f + 0.03f * wave
                Phase.LISTENING -> 0.08f + smoothLevel * 0.9f * (0.35f + 0.65f * wave)
                Phase.THINKING -> 0.10f + 0.22f * ((sin(t * 2f - i * 0.4f) + 1f) / 2f)
                Phase.SPEAKING -> 0.12f + 0.45f * wave * ((sin(t * 0.7f + i * 0.2f) + 1f) / 2f)
            }
            val h = (size.height * amp * envelope).coerceAtLeast(minH)
            drawRoundRect(
                color = Pk.Blue.copy(alpha = 0.16f),
                topLeft = Offset(x - barW, midY - h / 2f - 3.dp.toPx()),
                size = Size(barW * 2f, h + 6.dp.toPx()),
                cornerRadius = CornerRadius(barW)
            )
            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Pk.Blue, Pk.BlueDim),
                    startY = midY - h / 2f,
                    endY = midY + h / 2f
                ),
                topLeft = Offset(x - barW / 2f, midY - h / 2f),
                size = Size(barW, h),
                cornerRadius = CornerRadius(barW / 2f)
            )
        }
    }
}

@Composable
fun MicButton(phase: Phase, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val listening = phase == Phase.LISTENING
    val pulse = rememberInfiniteTransition(label = "pulse")
    val ring by pulse.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "ring"
    )
    Canvas(
        modifier
            .size(72.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = if (listening) "Stop listening" else "Start listening" }
    ) {
        val c = center
        val outer = size.minDimension / 2f
        val r = outer * 0.78f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Pk.Blue.copy(alpha = if (listening) 0.55f else 0.35f), Color.Transparent),
                center = c,
                radius = outer
            ),
            radius = outer
        )
        if (listening) {
            drawCircle(
                color = Pk.Blue.copy(alpha = 0.5f * (1f - ring)),
                radius = r + (outer - r) * ring,
                style = Stroke(2.dp.toPx())
            )
        }
        drawCircle(color = Pk.Surface, radius = r)
        drawCircle(color = Pk.Blue, radius = r, style = Stroke(2.dp.toPx()))

        if (listening) {
            val s = 16.dp.toPx()
            drawRoundRect(
                color = Pk.Blue,
                topLeft = Offset(c.x - s / 2f, c.y - s / 2f),
                size = Size(s, s),
                cornerRadius = CornerRadius(3.dp.toPx())
            )
        } else {
            val stroke = 2.dp.toPx()
            drawRoundRect(
                color = Pk.Blue,
                topLeft = Offset(c.x - 5.dp.toPx(), c.y - 13.dp.toPx()),
                size = Size(10.dp.toPx(), 18.dp.toPx()),
                cornerRadius = CornerRadius(5.dp.toPx())
            )
            drawArc(
                color = Pk.Blue,
                startAngle = 0f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset(c.x - 9.dp.toPx(), c.y - 9.dp.toPx()),
                size = Size(18.dp.toPx(), 16.dp.toPx()),
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
            drawLine(
                color = Pk.Blue,
                start = Offset(c.x, c.y + 7.dp.toPx()),
                end = Offset(c.x, c.y + 12.dp.toPx()),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
            drawLine(
                color = Pk.Blue,
                start = Offset(c.x - 5.dp.toPx(), c.y + 12.dp.toPx()),
                end = Offset(c.x + 5.dp.toPx(), c.y + 12.dp.toPx()),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun SendButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Canvas(
        modifier
            .size(56.dp)
            .clip(CircleShape)
            .background(Pk.Blue)
            .clickable(onClick = onClick)
            .semantics { contentDescription = "Send" }
    ) {
        val c = center
        val s = 9.dp.toPx()
        val w = 3.dp.toPx()
        drawLine(Pk.Bg, Offset(c.x, c.y + s), Offset(c.x, c.y - s), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(Pk.Bg, Offset(c.x - s * 0.75f, c.y - s * 0.1f), Offset(c.x, c.y - s), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(Pk.Bg, Offset(c.x + s * 0.75f, c.y - s * 0.1f), Offset(c.x, c.y - s), strokeWidth = w, cap = StrokeCap.Round)
    }
}

@Composable
fun StatusPill(online: Boolean, phase: Phase) {
    val phaseLabel = when (phase) {
        Phase.IDLE -> "Ready"
        Phase.LISTENING -> "Listening"
        Phase.THINKING -> "Thinking"
        Phase.SPEAKING -> "Speaking"
    }
    val shape = RoundedCornerShape(50)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(shape)
            .background(Pk.Surface)
            .border(1.dp, Pk.BlueDim.copy(alpha = 0.5f), shape)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Spacer(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (online) Pk.Ok else Pk.Error)
        )
        Spacer(Modifier.width(6.dp))
        Text(if (online) "Online" else "Offline", color = Pk.Text, fontSize = 12.sp)
        Spacer(Modifier.width(10.dp))
        Text(phaseLabel, color = Pk.TextDim, fontSize = 12.sp)
    }
}

@Composable
fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        text = label,
        color = if (selected) Pk.Bg else Pk.Text,
        fontSize = 13.sp,
        modifier = Modifier
            .clip(shape)
            .background(if (selected) Pk.Blue else Pk.Surface)
            .border(1.dp, if (selected) Pk.Blue else Pk.BlueDim.copy(alpha = 0.6f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
fun MessageBubble(m: ChatMessage) {
    val isUser = m.role == Role.USER
    val bg = when {
        m.isError -> Pk.Error.copy(alpha = 0.12f)
        isUser -> Pk.BlueDim.copy(alpha = 0.35f)
        else -> Pk.Surface
    }
    val border = when {
        m.isError -> Pk.Error.copy(alpha = 0.6f)
        isUser -> Pk.Blue.copy(alpha = 0.7f)
        else -> Pk.BlueDim.copy(alpha = 0.4f)
    }
    val shape = if (isUser) {
        RoundedCornerShape(16.dp, 16.dp, 4.dp, 16.dp)
    } else {
        RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp)
    }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Text(
            text = m.text,
            color = Pk.Text,
            fontSize = 15.sp,
            lineHeight = 21.sp,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .clip(shape)
                .background(bg)
                .border(1.dp, border, shape)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        )
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text, color = Pk.Blue, fontSize = 14.sp, fontWeight = FontWeight.Medium)
}

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = onBack) { Text("Back", color = Pk.Blue) }
        Text(title, color = Pk.Text, fontSize = 20.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
fun pkFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Pk.Blue,
    unfocusedBorderColor = Pk.BlueDim.copy(alpha = 0.6f),
    focusedTextColor = Pk.Text,
    unfocusedTextColor = Pk.Text,
    cursorColor = Pk.Blue,
    focusedLabelColor = Pk.Blue,
    unfocusedLabelColor = Pk.TextDim,
    focusedContainerColor = Pk.Surface,
    unfocusedContainerColor = Pk.Surface
)
