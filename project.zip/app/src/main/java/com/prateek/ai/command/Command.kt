package com.prateek.ai.command

enum class KnownApp(
    val label: String,
    val packageName: String,
    val webUrl: String,
    val aliases: List<String>
) {
    YOUTUBE(
        "YouTube", "com.google.android.youtube", "https://www.youtube.com",
        listOf("youtube", "you tube", "यूट्यूब", "यू ट्यूब")
    ),
    GOOGLE(
        "Google", "com.google.android.googlequicksearchbox", "https://www.google.com",
        listOf("google", "गूगल")
    ),
    INSTAGRAM(
        "Instagram", "com.instagram.android", "https://www.instagram.com",
        listOf("instagram", "insta", "इंस्टाग्राम", "इंस्टा")
    ),
    WHATSAPP(
        "WhatsApp", "com.whatsapp", "https://www.whatsapp.com",
        listOf("whatsapp", "whats app", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "व्हाट्स एप", "वाट्सएप")
    )
}

enum class SystemSettingsKind { GENERAL, WIFI }

enum class ClarifyKind { TIMER_DURATION, INVALID_TIMER, ALARM_TIME, INVALID_ALARM_TIME }

sealed class Command {
    data class OpenApp(val app: KnownApp) : Command()
    data class OpenSystemSettings(val kind: SystemSettingsKind) : Command()
    object TellTime : Command()
    object TellDate : Command()
    data class SetTimer(val seconds: Int) : Command()
    data class SetAlarm(val hour: Int, val minute: Int) : Command()
    data class Clarify(val kind: ClarifyKind) : Command()
}
